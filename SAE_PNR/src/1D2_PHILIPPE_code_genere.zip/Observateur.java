package donnee;

public class Observateur {

	private int idObservateur;
	private String nom;
	private String prenom;

	/**
	 * 
	 * @param id
	 * @param leNom
	 * @param lePrenom
	 */
	public Observateur(int id, String leNom, String lePrenom) {
		// TODO - implement Observateur.Observateur
		throw new UnsupportedOperationException();
	}

}