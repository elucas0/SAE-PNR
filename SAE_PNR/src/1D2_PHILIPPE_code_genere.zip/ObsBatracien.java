package donnee;

public class ObsBatracien extends Observation {

	private EspeceBatracien espece;
	private int nombreAdultes;
	private int nombreAmplexus;
	private int nombreTetard;
	private int nombrePonte;

	/**
	 * 
	 * @param id
	 * @param date
	 * @param heure
	 * @param lieu
	 * @param observateurs
	 */
	public ObsBatracien(int id, Date date, Time heure, Lieu lieu, ArrayList<Observateur> observateurs) {
		// TODO - implement ObsBatracien.ObsBatracien
		throw new UnsupportedOperationException();
	}

	public void operation() {
		// TODO - implement ObsBatracien.operation
		throw new UnsupportedOperationException();
	}

}