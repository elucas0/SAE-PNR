package donnee;

public enum EspeceObservee {
	LOUTRE,
	BATRACIEN,
	CHOUETTE,
	GCI,
	HIPPOCAMPE
}