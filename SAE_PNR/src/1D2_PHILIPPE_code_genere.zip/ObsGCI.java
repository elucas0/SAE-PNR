package donnee;

public class ObsGCI extends Observation {

	ContenuNid natureObs;
	private int nombre;

	/**
	 * 
	 * @param id
	 * @param date
	 * @param heure
	 * @param lieu
	 * @param observateur
	 * @param nature
	 * @param leNombre
	 */
	public ObsGCI(integer id, Date date, Time heure, Lieu lieu, ArrayList<Observateur> observateur, ContenuNid nature, int leNombre) {
		// TODO - implement ObsGCI.ObsGCI
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param id
	 * @param date
	 * @param heure
	 * @param lieu
	 * @param observateur
	 * @param nature
	 * @param leNombre
	 */
	public ObsGCI(integer id, Date date, Time heure, Lieu lieu, ArrayList<Observateur> observateur, ContenuNid nature, int leNombre) {
		// TODO - implement ObsGCI.ObsGCI
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param id
	 * @param date
	 * @param heure
	 * @param lieu
	 * @param observateur
	 * @param nature
	 * @param leNombre
	 */
	public ObsGCI(integer id, Date date, Time heure, Lieu lieu, ArrayList<Observateur> observateur, ContenuNid nature, int leNombre) {
		// TODO - implement ObsGCI.ObsGCI
		throw new UnsupportedOperationException();
	}

}