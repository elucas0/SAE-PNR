package donnee;

public class ObsHippocampe extends Observation {

	private Peche typePeche;
	private EspeceHippocampe espece;
	private Sexe sexe;
	private double taille;
	private boolean estGestant;
	private int attribute;

	/**
	 * 
	 * @param id
	 * @param date
	 * @param heure
	 * @param lieu
	 * @param observateur
	 * @param laTaille
	 * @param leTypePeche
	 * @param lEspece
	 * @param leSexe
	 */
	public ObsHippocampe(integer id, Date date, Time heure, Lieu lieu, ArrayList<Observateur> observateur, double laTaille, Peche leTypePeche, EspeceHippocampe lEspece, Sexe leSexe) {
		// TODO - implement ObsHippocampe.ObsHippocampe
		throw new UnsupportedOperationException();
	}

	public void operation() {
		// TODO - implement ObsHippocampe.operation
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param id
	 * @param date
	 * @param heure
	 * @param lieu
	 * @param observateur
	 * @param laTaille
	 * @param leTypePeche
	 * @param lEspece
	 * @param leSexe
	 */
	public ObsHippocampe(integer id, Date date, Time heure, Lieu lieu, ArrayList<Observateur> observateur, double laTaille, Peche leTypePeche, EspeceHippocampe lEspece, Sexe leSexe) {
		// TODO - implement ObsHippocampe.ObsHippocampe
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param id
	 * @param date
	 * @param heure
	 * @param lieu
	 * @param observateur
	 * @param laTaille
	 * @param leTypePeche
	 * @param lEspece
	 * @param leSexe
	 */
	public ObsHippocampe(integer id, Date date, Time heure, Lieu lieu, ArrayList<Observateur> observateur, double laTaille, Peche leTypePeche, EspeceHippocampe lEspece, Sexe leSexe) {
		// TODO - implement ObsHippocampe.ObsHippocampe
		throw new UnsupportedOperationException();
	}

}