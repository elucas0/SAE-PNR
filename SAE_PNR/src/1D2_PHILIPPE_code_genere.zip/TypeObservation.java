package donnee;

public enum TypeObservation {
	SONORE,
	VISUELLE,
	SONORE_VISUELLE
}