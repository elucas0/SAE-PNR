package donnee;

public enum EspeceChouette {
	EFFRAIE,
	CHEVECHE,
	HULOTTE
}