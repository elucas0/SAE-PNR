package donnee;

public enum Sexe {
	MALE,
	FEMELLE,
	INCONNU
}