package donnee;

public class Chouette {

	private Sexe sexe;
	private ObsChouette lesObservations;
	private EspeceChouette espece;
	private String idChouette;

	/**
	 * 
	 * @param id
	 * @param leSexe
	 * @param lEspece
	 */
	public Chouette(String id, Sexe leSexe, EspeceChouette lEspece) {
		// TODO - implement Chouette.Chouette
		throw new UnsupportedOperationException();
	}

}