package donnee;

public enum ContenuNid {
	OEUF,
	POUSSIN,
	NID_SEUL
}