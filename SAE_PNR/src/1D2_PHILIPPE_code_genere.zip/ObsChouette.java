package donnee;

public class ObsChouette extends Observation {

	private TypeObservation typeObs;

	/**
	 * 
	 * @param id
	 * @param date
	 * @param heure
	 * @param lieu
	 * @param observateur
	 * @param type
	 */
	public ObsChouette(integer id, Date date, Time heure, Lieu lieu, ArrayList<Observateur> observateur, TypeObservation type) {
		// TODO - implement ObsChouette.ObsChouette
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param id
	 * @param date
	 * @param heure
	 * @param lieu
	 * @param observateur
	 * @param type
	 */
	public ObsChouette(integer id, Date date, Time heure, Lieu lieu, ArrayList<Observateur> observateur, TypeObservation type) {
		// TODO - implement ObsChouette.ObsChouette
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param id
	 * @param date
	 * @param heure
	 * @param lieu
	 * @param observateur
	 * @param type
	 */
	public ObsChouette(integer id, Date date, Time heure, Lieu lieu, ArrayList<Observateur> observateur, TypeObservation type) {
		// TODO - implement ObsChouette.ObsChouette
		throw new UnsupportedOperationException();
	}

}