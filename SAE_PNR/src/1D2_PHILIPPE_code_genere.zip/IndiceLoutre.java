package donnee;

public enum IndiceLoutre {
	POSITIF,
	NEGATIF,
	NON_PROSPECTION
}