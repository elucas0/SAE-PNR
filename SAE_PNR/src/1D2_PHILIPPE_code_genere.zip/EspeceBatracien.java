package donnee;

public enum EspeceBatracien {
	CALAMITE,
	PELODYTE
}