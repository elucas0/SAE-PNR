package donnee;

public class ObsLoutre extends Observation {

	private IndiceLoutre indice;

	/**
	 * 
	 * @param id
	 * @param date
	 * @param heure
	 * @param lieu
	 * @param observateur
	 * @param indice
	 */
	public ObsLoutre(integer id, Date date, Time heure, Lieu lieu, ArrayList<Observateur> observateur, IndiceLoutre indice) {
		// TODO - implement ObsLoutre.ObsLoutre
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param id
	 * @param date
	 * @param heure
	 * @param lieu
	 * @param observateur
	 * @param indice
	 */
	public ObsLoutre(integer id, Date date, Time heure, Lieu lieu, ArrayList<Observateur> observateur, IndiceLoutre indice) {
		// TODO - implement ObsLoutre.ObsLoutre
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param id
	 * @param date
	 * @param heure
	 * @param lieu
	 * @param observateur
	 * @param indice
	 */
	public ObsLoutre(integer id, Date date, Time heure, Lieu lieu, ArrayList<Observateur> observateur, IndiceLoutre indice) {
		// TODO - implement ObsLoutre.ObsLoutre
		throw new UnsupportedOperationException();
	}

}