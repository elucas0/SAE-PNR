package donnee;

public class Lieu {

	private double xCoord;
	private double yCoord;

	/**
	 * 
	 * @param x
	 * @param y
	 */
	public Lieu(double x, double y) {
		// TODO - implement Lieu.Lieu
		throw new UnsupportedOperationException();
	}

}