package donnee;

import java.util.*;

public class NidGCI {

	private Collection<ObsGCI> lesObservations;
	private int idNid;
	private int nbEnvol;
	private String nomPlage;

	/**
	 * 
	 * @param id
	 * @param plage
	 */
	public NidGCI(int id, String plage) {
		// TODO - implement NidGCI.NidGCI
		throw new UnsupportedOperationException();
	}

	public Date dateDEbutObs() {
		// TODO - implement NidGCI.dateDEbutObs
		throw new UnsupportedOperationException();
	}

	public Date dateFinObs() {
		// TODO - implement NidGCI.dateFinObs
		throw new UnsupportedOperationException();
	}

}